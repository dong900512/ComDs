/*
状态管理常量
 */
const LOGIN = '_LOGIN'//设置登录状态
const LOGINOUT = '_LOGINOUT'//设置注销状态
export { LOGIN, LOGINOUT }