﻿const baseUrl = "http://115.159.101.210:8067" //发布url
//const baseUrl = "http://localhost:50123" //本地Url
export { baseUrl }