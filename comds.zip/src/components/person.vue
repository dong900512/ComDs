<template>
    <div>
        <h1>个人信息</h1>
    </div>
</template>
<script>
    export default{
        name:'person',
        data () {
            return {
                
            }
        }
    }
</script>