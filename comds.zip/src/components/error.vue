<template>
    <div>
        <h3>我们也在寻找这个页面</h3>
    </div>
</template>
<script>
export default {
    name: 'error'
}
</script>